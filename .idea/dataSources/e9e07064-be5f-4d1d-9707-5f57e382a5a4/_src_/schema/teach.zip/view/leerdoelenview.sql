CREATE VIEW `leerdoelenview` AS
  SELECT
    `teach`.`thema`.`les_id`   AS `les_id`,
    `teach`.`thema`.`leerdoel` AS `omschrijving`
  FROM `teach`.`thema`