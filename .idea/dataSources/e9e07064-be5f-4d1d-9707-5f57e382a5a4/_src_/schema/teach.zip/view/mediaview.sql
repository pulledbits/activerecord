CREATE VIEW `mediaview` AS
  SELECT DISTINCT
    `teach`.`les`.`id`             AS `les_id`,
    `teach`.`media`.`omschrijving` AS `omschrijving`
  FROM ((((`teach`.`les`
    LEFT JOIN `teach`.`thema` ON ((`teach`.`thema`.`les_id` = `teach`.`les`.`id`))) LEFT JOIN `teach`.`activiteit`
      ON ((`teach`.`activiteit`.`id` IN
           (`teach`.`les`.`activerende_opening_id`, `teach`.`les`.`focus_id`, `teach`.`les`.`voorstellen_id`, `teach`.`les`.`kennismaken_id`, `teach`.`les`.`terugblik_id`, `teach`.`les`.`huiswerk_id`, `teach`.`les`.`evaluatie_id`, `teach`.`les`.`pakkend_slot_id`, `teach`.`thema`.`ervaren_id`, `teach`.`thema`.`reflecteren_id`, `teach`.`thema`.`conceptualiseren_id`, `teach`.`thema`.`toepassen_id`)))) JOIN
    `teach`.`activiteitmedia` ON ((`teach`.`activiteitmedia`.`activiteit_id` = `teach`.`activiteit`.`id`))) JOIN
    `teach`.`media` ON ((`teach`.`media`.`id` = `teach`.`activiteitmedia`.`media_id`)))